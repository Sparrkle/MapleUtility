﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapleUtility.Plugins.Common
{
    public class MaplestoryTimeOutException : Exception
    {
    }

    public class DataUnmatchedException : Exception
    {
    }
}
